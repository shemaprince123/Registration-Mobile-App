package com.example.registration1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "MyDatabase.db";

    private static final String TABLE_REGISTRATION = "Registration";
    private static final String COLUMN_REGISTRATION_ID = "ID";
    private static final String COLUMN_FIRST_NAME = "FirstName";
    private static final String COLUMN_LAST_NAME = "LastName";
    private static final String COLUMN_ID_NUMBER = "IDNumber";
    private static final String COLUMN_MAJOR = "Major";

    private static final String TABLE_FEES = "Fees";
    private static final String COLUMN_FEES_ID = "ID";
    private static final String COLUMN_FEES_ID_NUMBER = "IDNumber";
    private static final String COLUMN_TOTAL_FEES = "TotalFees";
    private static final String COLUMN_FEES_PAID = "FeesPaid";
    private static final String COLUMN_FEE_BALANCE = "FeeBalance";
    private static final String COLUMN_CLEARANCE_DATE = "ClearanceDate";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createRegistrationTableQuery = "CREATE TABLE " + TABLE_REGISTRATION + " (" +
                COLUMN_REGISTRATION_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_FIRST_NAME + " TEXT," +
                COLUMN_LAST_NAME + " TEXT," +
                COLUMN_ID_NUMBER + " TEXT," +
                COLUMN_MAJOR + " TEXT)";

        String createFeesTableQuery = "CREATE TABLE " + TABLE_FEES + " (" +
                COLUMN_FEES_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                COLUMN_FEES_ID_NUMBER + " TEXT," +
                COLUMN_TOTAL_FEES + " REAL," +
                COLUMN_FEES_PAID + " REAL," +
                COLUMN_FEE_BALANCE + " REAL," +
                COLUMN_CLEARANCE_DATE + " TEXT)";

        db.execSQL(createRegistrationTableQuery);
        db.execSQL(createFeesTableQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_REGISTRATION);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_FEES);
        onCreate(db);
    }

    public long insertRegistrationData(String firstName, String lastName, String idNumber, String major) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FIRST_NAME, firstName);
        values.put(COLUMN_LAST_NAME, lastName);
        values.put(COLUMN_ID_NUMBER, idNumber);
        values.put(COLUMN_MAJOR, major);
        return db.insert(TABLE_REGISTRATION, null, values);
    }

    public long insertFeesData(String idNumber, double totalFees, double feesPaid, double feeBalance, String clearanceDate) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FEES_ID_NUMBER, idNumber);
        values.put(COLUMN_TOTAL_FEES, totalFees);
        values.put(COLUMN_FEES_PAID, feesPaid);
        values.put(COLUMN_FEE_BALANCE, feeBalance);
        values.put(COLUMN_CLEARANCE_DATE, clearanceDate);
        return db.insert(TABLE_FEES, null, values);
    }

    public Cursor getRegistrationData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_REGISTRATION;
        return db.rawQuery(query, null);
    }

    public Cursor getFeesData() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_FEES;
        return db.rawQuery(query, null);
    }

    // Add methods for updating and deleting data if needed
}
