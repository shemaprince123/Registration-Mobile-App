package com.example.registration1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class SummaryTabFragment extends Fragment {

    private TextView summaryTextView;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_summary_tab, container, false);

        summaryTextView = view.findViewById(R.id.summaryTextView);
        databaseHelper = new DatabaseHelper(getActivity());

        displaySummary();

        return view;
    }

    private void displaySummary() {
        Cursor registrationCursor = databaseHelper.getRegistrationData();
        Cursor feesCursor = databaseHelper.getFeesData();

        StringBuilder summaryData = new StringBuilder();

        if (registrationCursor.getCount() == 0 || feesCursor.getCount() == 0) {
            summaryData.append("No data available");
        } else {
            while (registrationCursor.moveToNext()) {
                String idNumber = registrationCursor.getString(registrationCursor.getColumnIndex("IDNumber"));
                String firstName = registrationCursor.getString(registrationCursor.getColumnIndex("FirstName"));
                String major = registrationCursor.getString(registrationCursor.getColumnIndex("Major"));

                summaryData.append("ID Number: ").append(idNumber).append("\n");
                summaryData.append("First Name: ").append(firstName).append("\n");
                summaryData.append("Major: ").append(major).append("\n\n");

                feesCursor.moveToFirst(); // Reset the feesCursor to the beginning

                while (!feesCursor.isAfterLast()) {
                    String feesIdNumber = feesCursor.getString(feesCursor.getColumnIndex("IDNumber"));
                    double totalFees = feesCursor.getDouble(feesCursor.getColumnIndex("TotalFees"));
                    double feeBalance = feesCursor.getDouble(feesCursor.getColumnIndex("FeeBalance"));
                    String clearanceDate = feesCursor.getString(feesCursor.getColumnIndex("ClearanceDate"));

                    if (idNumber.equals(feesIdNumber)) {
                        summaryData.append("Total Fees: ").append(totalFees).append("\n");
                        summaryData.append("Fee Balance: ").append(feeBalance).append("\n");
                        summaryData.append("Clearance Date: ").append(clearanceDate).append("\n\n");
                    }

                    feesCursor.moveToNext(); // Move to the next row in feesCursor
                }
            }
        }

        summaryTextView.setText(summaryData.toString());
    }
}
