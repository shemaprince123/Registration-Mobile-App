package com.example.registration1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class FeesTabFragment extends Fragment {

    private EditText idNumberEditText, totalFeesEditText, feesPaidEditText, clearanceDateEditText;
    private Button insertButton, updateButton, deleteButton, viewButton;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_fees_tab, container, false);

        idNumberEditText = view.findViewById(R.id.idNumberEditText);
        totalFeesEditText = view.findViewById(R.id.totalFeesEditText);
        feesPaidEditText = view.findViewById(R.id.feesPaidEditText);
        clearanceDateEditText = view.findViewById(R.id.clearanceDateEditText);
        insertButton = view.findViewById(R.id.insertButton);
        updateButton = view.findViewById(R.id.updateButton);
        deleteButton = view.findViewById(R.id.deleteButton);
        viewButton = view.findViewById(R.id.viewButton);

        databaseHelper = new DatabaseHelper(getActivity());

        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String idNumber = idNumberEditText.getText().toString();
                double totalFees = Double.parseDouble(totalFeesEditText.getText().toString());
                double feesPaid = Double.parseDouble(feesPaidEditText.getText().toString());
                double feeBalance = totalFees - feesPaid;
                String clearanceDate = clearanceDateEditText.getText().toString();

                long result = databaseHelper.insertFeesData(idNumber, totalFees, feesPaid, feeBalance, clearanceDate);

                if (result != -1) {
                    Toast.makeText(getActivity(), "Data inserted successfully", Toast.LENGTH_SHORT).show();
                    clearFields();
                } else {
                    Toast.makeText(getActivity(), "Failed to insert data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = databaseHelper.getFeesData();
                if (cursor.getCount() == 0) {
                    Toast.makeText(getActivity(), "No data available", Toast.LENGTH_SHORT).show();
                } else {
                    StringBuilder data = new StringBuilder();
                    while (cursor.moveToNext()) {
                        String idNumber = cursor.getString(cursor.getColumnIndex("IDNumber"));
                        double totalFees = cursor.getDouble(cursor.getColumnIndex("TotalFees"));
                        double feesPaid = cursor.getDouble(cursor.getColumnIndex("FeesPaid"));
                        double feeBalance = cursor.getDouble(cursor.getColumnIndex("FeeBalance"));
                        String clearanceDate = cursor.getString(cursor.getColumnIndex("ClearanceDate"));
                        data.append("ID Number: ").append(idNumber).append("\n");
                        data.append("Total Fees: ").append(totalFees).append("\n");
                        data.append("Fees Paid: ").append(feesPaid).append("\n");
                        data.append("Fee Balance: ").append(feeBalance).append("\n");
                        data.append("Clearance Date: ").append(clearanceDate).append("\n\n");
                    }
                    Toast.makeText(getActivity(), data.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        // TODO: Implement the update and delete button click listeners

        return view;
    }

    private void clearFields() {
        idNumberEditText.setText("");
        totalFeesEditText.setText("");
        feesPaidEditText.setText("");
        clearanceDateEditText.setText("");
    }
}
