package com.example.registration1;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

public class RegistrationTabFragment extends Fragment {

    private EditText firstNameEditText, lastNameEditText, idNumberEditText, majorEditText;
    private Button insertButton, updateButton, deleteButton, viewButton;
    private DatabaseHelper databaseHelper;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_registration_tab, container, false);

        firstNameEditText = view.findViewById(R.id.firstNameEditText);
        lastNameEditText = view.findViewById(R.id.lastNameEditText);
        idNumberEditText = view.findViewById(R.id.idNumberEditText);
        majorEditText = view.findViewById(R.id.majorEditText);
        insertButton = view.findViewById(R.id.insertButton);
        updateButton = view.findViewById(R.id.updateButton);
        deleteButton = view.findViewById(R.id.deleteButton);
        viewButton = view.findViewById(R.id.viewButton);

        databaseHelper = new DatabaseHelper(getActivity());

        insertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String firstName = firstNameEditText.getText().toString();
                String lastName = lastNameEditText.getText().toString();
                String idNumber = idNumberEditText.getText().toString();
                String major = majorEditText.getText().toString();

                long result = databaseHelper.insertRegistrationData(firstName, lastName, idNumber, major);

                if (result != -1) {
                    Toast.makeText(getActivity(), "Data inserted successfully", Toast.LENGTH_SHORT).show();
                    clearFields();
                } else {
                    Toast.makeText(getActivity(), "Failed to insert data", Toast.LENGTH_SHORT).show();
                }
            }
        });

        viewButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor cursor = databaseHelper.getRegistrationData();
                if (cursor.getCount() == 0) {
                    Toast.makeText(getActivity(), "No data available", Toast.LENGTH_SHORT).show();
                } else {
                    StringBuilder data = new StringBuilder();
                    while (cursor.moveToNext()) {
                        String firstName = cursor.getString(cursor.getColumnIndex("FirstName"));
                        String idNumber = cursor.getString(cursor.getColumnIndex("IDNumber"));
                        String major = cursor.getString(cursor.getColumnIndex("Major"));
                        data.append("First Name: ").append(firstName).append("\n");
                        data.append("ID Number: ").append(idNumber).append("\n");
                        data.append("Major: ").append(major).append("\n\n");
                    }
                    Toast.makeText(getActivity(), data.toString(), Toast.LENGTH_LONG).show();
                }
            }
        });

        // TODO: Implement the update and delete button click listeners

        return view;
    }

    private void clearFields() {
        firstNameEditText.setText("");
        lastNameEditText.setText("");
        idNumberEditText.setText("");
        majorEditText.setText("");
    }
}
